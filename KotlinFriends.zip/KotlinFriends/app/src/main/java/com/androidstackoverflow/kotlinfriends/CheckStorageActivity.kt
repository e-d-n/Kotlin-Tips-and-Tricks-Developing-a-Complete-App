package com.androidstackoverflow.kotlinfriends

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.view.View
import com.androidstackoverflow.kotlinfriends.Contact.Companion.MANUALLY_SET
import com.androidstackoverflow.kotlinfriends.Contact.Companion.THE_PATH
import com.androidstackoverflow.kotlinfriends.Contact.Companion.whichPIC
import kotlinx.android.synthetic.main.activity_check_storage.*
import java.io.File

class CheckStorageActivity : AppCompatActivity() {

    private val STORAGE_PERMISSION_CODE = 1
    var STORAGE_LOCATION: Int = 3
    var the_path = ""
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_storage)
        supportActionBar?.hide()

        // This code runs if Permission has been Granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            val sharedPreferences = getSharedPreferences("SecondPref", Context.MODE_PRIVATE)
            the_path = sharedPreferences.getString("DB_PATH", "")

            if(the_path != "") {
                pathONLY()
            }
        }
        // Code below runs if Permission has NOT been Granted OR Changed in Settings------ LOOK BELOW
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestStoragePermission()
        }

    }// end onCreate

    // Manage Navigations if Permission Manually Set by user
    // and the App has not been closed or removed from recent
    override fun onResume() {
        super.onResume()
        if(MANUALLY_SET == 2){
            pathALL()
        }
    }

    fun pathALL(){

        val fi = File("storage/")
        val lst = fi.listFiles()
        val top = lst[1].toString()
        val bot = lst[0].toString()

        println("TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT top $top")
        // SET this value on the EMULATOR (top.contains("storage/self")
        // THIS MUST BE USED ON emulator to test
        // For real device testing use (top.contains("storage/emulated")
        // ===============================================================
        println("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB bot $bot")
        // SET this value on the EMULATOR (top.contains("storage/emulated")
        // For real devide testing use (bot.contains("-")
        // Do not use on Emulator it will NOT work
        // ================================================================
        if (top.contains("storage/self")) {
            STORAGE_LOCATION = 0
            internalDIALOG()
        }
        if (bot.contains("-")) {
            STORAGE_LOCATION = 1
            externalDIALOG()
        }
    }

    fun pathONLY(){
        // This maintains the vaule for THE_PATH by reading it from Shared Preference SecondPref
        val sharedPreferences = getSharedPreferences("SecondPref", Context.MODE_PRIVATE)
        the_path = sharedPreferences.getString("DB_PATH", "")
        THE_PATH = the_path
        whichPIC = 4
        showIMAGE()
        // To eliminate showIMAGE use code below
        // val intent = Intent(this, MainActivity::class.java)
        // startActivity(intent)
    }

    fun writeSharedPrefANDleave(){

        val sharedPreferences = getSharedPreferences("SecondPref", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("DB_PATH", THE_PATH)
        editor.apply()
        showIMAGE()
        // To eliminate showIMAGE use code below
        // val intent = Intent(this, MainActivity::class.java)
        // startActivity(intent)
    }

    private fun showIMAGE(context: Context = this) {
        object : CountDownTimer(6000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                if(whichPIC == 0){
                    // csaCL is the id of the Constraint Layout in activity_check_storage.xml
                    csaCL.setBackgroundColor(Color.parseColor("#808080"))
                    imageViewFirst.visibility = View.VISIBLE
                }else{
                    csaCL.setBackgroundColor(Color.parseColor("#F224251F"))
                    imageViewSecond.visibility = View.VISIBLE
                }
            }
            override fun onFinish() {
                //val context:Context = baseContext
                val intent = Intent(context, MainActivity::class.java)
                startActivity(intent)
            }
        }.start()
    }

    fun internalDIALOG() {

        AlertDialog.Builder(this)
        .setCancelable(false)
        .setTitle("SD Card NOT Mounted")
        .setMessage("\nClick OK to use INTERNAL Device Storage")

        .setNeutralButton("OK"){_, _ ->
            STORAGE_LOCATION = 0
            setThePath()
            writeSharedPrefANDleave()
        }
        .show()
    }

    fun externalDIALOG() {

        AlertDialog.Builder(this)
        .setCancelable(false)
        .setTitle("Select Data Storage Location ")
        .setMessage("EXTERNAL Use SD CARD\n\n" + "INTERNAL Device Storage")

        .setPositiveButton("EXTERNAL") {_, _ ->
            STORAGE_LOCATION = 1
            setThePath()
            writeSharedPrefANDleave()
        }
        .setNegativeButton("INTERNAL") { _, _ ->
            STORAGE_LOCATION = 0
            setThePath()
            writeSharedPrefANDleave()
        }
        .show()
    }

    fun setThePath(): String {

        val removable = ContextCompat.getExternalFilesDirs(this, null)[STORAGE_LOCATION]

        if (STORAGE_LOCATION == 1) {
            THE_PATH = removable.toString()
            THE_PATH = THE_PATH + "/Documents/"
        }
        if (STORAGE_LOCATION == 0) {
            THE_PATH = removable.toString()
            THE_PATH = THE_PATH + "/INTERNAL/"
        }
        return THE_PATH.trim()
    }

    private fun requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            AlertDialog.Builder(this)
                .setTitle("Uninstall App or Set Permissions")
                .setMessage("On the Next Screen to Uninstall the App\n\nCheck Don't Ask Again and Click DENY\n\nOR Click ALLOW to Grant Permission")

                .setPositiveButton("NEXT") { _, _ ->
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), STORAGE_PERMISSION_CODE)
                }
                .create().show()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), STORAGE_PERMISSION_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == STORAGE_PERMISSION_CODE) {

            // User selected Allowed and Permission was Granted
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                pathALL()

            } else {

                // User checked the box Do Not Ask Again in the Dialog and User selected Deny in the Dialog
                if (Build.VERSION.SDK_INT >= 23 && !shouldShowRequestPermissionRationale(permissions[0])) {

                    AlertDialog.Builder(this)
                    .setTitle("Set Permissions or UN-Install App")
                        .setMessage("Click SETTINGS to Manually set Permission\n\n"+"OR to UN-Install the Application")
                        .setCancelable(false)

                        .setPositiveButton("SETTINGS") { _, _ ->
                            MANUALLY_SET = 2
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            startActivityForResult(intent, 1000)
                        }
                        .show()

                } else run {
                    // User selected ONLY Deny in the Dialog
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {

                        AlertDialog.Builder(this)
                        .setTitle("Click RETRY for More Options")
                            .setMessage("For the app to Save Data Allow Permissions\n\n"+"NO Personal Information is Sharred")
                            .setCancelable(false)

                            .setPositiveButton("RETRY") {dialog, _ ->
                                dialog.cancel()
                                val intent = Intent(this, CheckStorageActivity::class.java)
                                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                startActivity(intent)
                            }
                        .show()
                    }
                }
            }
        }
    }

}// end Class


