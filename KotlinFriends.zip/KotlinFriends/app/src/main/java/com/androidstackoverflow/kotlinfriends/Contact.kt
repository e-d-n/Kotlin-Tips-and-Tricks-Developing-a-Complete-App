package com.androidstackoverflow.kotlinfriends

data class Contact(var id: Int = 0,var person:String = "",var phone:String = "") {

    companion object { var THE_PATH = "";var whichPIC = 0;var MANUALLY_SET = 1 }
}