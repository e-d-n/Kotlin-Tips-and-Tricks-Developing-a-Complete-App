package com.androidstackoverflow.kotlinfriends

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

class ContactAdapter(friendList:List<Contact>,internal var context: Context):RecyclerView.Adapter<ContactAdapter.MyViewHolder>() {

    private var friendList:List<Contact> = ArrayList()
    init { this.friendList = friendList}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.card_contact,parent,false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return friendList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val items = friendList[position]
        holder.item1.text = items.person
        holder.item2.text = items.phone

        holder.ivEdit.setOnClickListener {

            //val rowid = friendList.get(position).id
            val intent = Intent(context, MainActivity::class.java)
            intent.putExtra("FROM", "UPDATE")
            intent.putExtra("recordID", items.id)
            intent.putExtra("PERSON", items.person)
            intent.putExtra("PHONE", items.phone)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        }

        holder.ivDelete.setOnClickListener {

            val intent = Intent(context, MainActivity::class.java)
            intent.putExtra("FROM", "DELETE")
            intent.putExtra("recordID", items.id)
            intent.putExtra("PERSON", items.person)
            intent.putExtra("PHONE", items.phone)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        }
    }

    inner class MyViewHolder(view: View): RecyclerView.ViewHolder(view){
        var item1: TextView = view.findViewById(R.id.tvPerson) as TextView
        var item2: TextView = view.findViewById(R.id.tvPhone) as TextView
        var ivEdit:ImageView = view.findViewById(R.id.ivEdit) as ImageView
        var ivDelete:ImageView = view.findViewById(R.id.ivDelete) as ImageView
    }

}