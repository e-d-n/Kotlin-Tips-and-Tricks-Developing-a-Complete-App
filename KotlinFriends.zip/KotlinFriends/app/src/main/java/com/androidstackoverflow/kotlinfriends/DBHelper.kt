package com.androidstackoverflow.kotlinfriends

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast
import com.androidstackoverflow.kotlinfriends.Contact.Companion.THE_PATH

class DBHelper(private val context: Context): SQLiteOpenHelper(context,DBHelper.DB_NAME,null,DBHelper.DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_TABLE_SQL = "CREATE TABLE IF NOT EXISTS " + FRIEND_TABLE + " (" + colId + " INTEGER PRIMARY KEY," + colPerson + " TEXT, " + colPhone + " TEXT);"
        db!!.execSQL(CREATE_TABLE_SQL)
        Toast.makeText(context,"Database was Created", Toast.LENGTH_LONG).show()
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val DROP_FRIEND_TABLE = "DROP TABLE IF EXISTS $FRIEND_TABLE"
        db!!.execSQL(DROP_FRIEND_TABLE)
        onCreate(db)
        Toast.makeText(context,"Table Dropped new DB Created", Toast.LENGTH_LONG).show()
    }

    fun queryFRIEND(): ArrayList<Contact> {

        val db = this.writableDatabase
        val friendList = ArrayList<Contact>()
        //val selectQuery = "SELECT  * FROM $FRIEND_TABLE "
        val selectQuery = "SELECT * FROM $FRIEND_TABLE ORDER BY $colPerson ASC"
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    val contact = Contact()
                    contact.id = Integer.parseInt(cursor.getString(cursor.getColumnIndex(colId)))
                    contact.person = cursor.getString(cursor.getColumnIndex(colPerson))
                    contact.phone = cursor.getString(cursor.getColumnIndex(colPhone))
                    friendList.add(contact)
                } while (cursor.moveToNext())
            }
        }
        cursor.close()
        db.close()
        return friendList
    }

    fun insertFRIEND(values: ContentValues): Long {
        val db = this.writableDatabase
        val id = db.insert(FRIEND_TABLE, null, values)
        db.close()
        return id
    }

    fun updateFRIEND(values: ContentValues, selection: String, selectionargs: Array<String>):Int{
        val db = this.writableDatabase
        val countID = db.update(FRIEND_TABLE,values,selection,selectionargs)
        db.update(FRIEND_TABLE, values, "$colId = ?", selectionargs)
        db.close()
        return countID
    }

    fun deleteFRIEND(productname: String): Boolean {
        var result = false
        val query = "SELECT * FROM $FRIEND_TABLE WHERE $colPerson= \"$productname\""
        val db = this.writableDatabase
        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            val id = Integer.parseInt(cursor.getString(0))
            db.delete(FRIEND_TABLE, "$colId = ?", arrayOf(id.toString()))
            cursor.close()
            result = true
        }
        db.close()
        return result
    }

    companion object {
        private val DB_VERSION = 1
        private val DB_NAME = THE_PATH+"ContactList.db"
        private val FRIEND_TABLE = "Friends"
        private val colId = "id"
        private val colPerson = "Person"
        private val colPhone = "Phone"
    }
}


