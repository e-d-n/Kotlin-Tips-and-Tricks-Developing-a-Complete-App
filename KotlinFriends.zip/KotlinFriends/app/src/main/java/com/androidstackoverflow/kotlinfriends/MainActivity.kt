package com.androidstackoverflow.kotlinfriends

import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.support.design.widget.Snackbar
import android.support.v7.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

open class MainActivity : AppCompatActivity() {

    var id = 0
    var from = ""
    var sbSTRING = ""
    // variable from manages UPDATE
    // NEW as well as DELETE Records
    var txtPerson = ""
    var txtPhone =  ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Manage Contacts"
        etPerson.requestFocus()

        try {
            val bundle: Bundle = intent.extras
            from = bundle.getString("FROM","")
            txtPerson = bundle.getString("PERSON","")
            txtPhone = bundle.getString("PHONE","")

            if(from == "UPDATE") {
                showMSG("To CANCEL use back button")
                id = bundle.getInt("recordID", 4)
                btnAdd.visibility = View.INVISIBLE
                btnEdit.visibility = View.VISIBLE
                btnViewList.visibility = View.INVISIBLE
                etPerson.setText(txtPerson)
                etPhone.setText(txtPhone)

            }else if (from == "DELETE"){

                showMSG("To CANCEL use back button")
                btnAdd.visibility = View.INVISIBLE
                btnViewList.visibility = View.INVISIBLE
                btnEdit.visibility = View.INVISIBLE
                btnDelete.visibility = View.VISIBLE
                etPerson.setText(txtPerson)
                etPhone.setText(txtPhone)
                etPerson.isEnabled = false
                etPhone.isEnabled = false

            }else{

                btnViewList.visibility = View.VISIBLE
                btnAdd.visibility = View.VISIBLE
                btnEdit.visibility = View.INVISIBLE
            }
        } catch (ex: Exception) {
        }

        btnAdd.setOnClickListener {

            if(etPerson.text.toString().equals("")){
                showMSG("ENTER Contacts Name")
                etPerson.requestFocus()
                return@setOnClickListener
            }

            if(etPhone.text.toString().equals("")){
                showMSG("ENTER Phone Number")
                etPhone.requestFocus()
                return@setOnClickListener
            }

            val db = DBHelper(this)

            val values = ContentValues()
            values.put("person", etPerson.text.toString().trim())
            values.put("phone", etPhone.text.toString().trim())

            if (id == 0) {
                val mID = db.insertFRIEND(values)
                if (mID > 0) {
                    showMSG("ADDED contact successfully")
                    nextACTIVITY()
                } else {
                    showMSG("Failed to contact person")
                }
            }
        }

        btnEdit.setOnClickListener {

            if (etPerson.text.toString().equals("")) {
                showMSG("ENTER contacts name")
                etPerson.requestFocus()
                return@setOnClickListener
            }

            if (etPhone.text.toString().equals("")) {
                showMSG("ENTER phone number")
                etPhone.requestFocus()
                return@setOnClickListener
            }

            val db = DBHelper(this)

            val values = ContentValues()
            values.put("person", etPerson.text.toString())
            values.put("phone", etPhone.text.toString())

            if (id > 0) {
                // IN UPDATE id needs to be id > 0
                val selectionArs = arrayOf(id.toString())

                val mID = db.updateFRIEND(values, "id=?", selectionArs)
                if (mID > 0) {
                    //tvMsg.setTextColor(Color.RED)
                    showMSG("Updated Contact Successfully")
                    nextACTIVITY()
                } else {
                    showMSG("Failed to Update Contact")
                }
            }
        }

        btnViewList.setOnClickListener { nextACTIVITY() }

        btnDelete.setOnClickListener { doCustom() }

    }// end on Create

    //@SuppressLint("InflateParams")
    fun doCustom() {
        /* This method uses the custom_dialog.xml file created for greater control over
       the styling of the Custom Alert Dialog for various screen sizes and to be
       able to set the text size of the dialog message text
       */
        val makeDialog = LayoutInflater.from(this).inflate(R.layout.custom_dialog,null)

        val mBuilder = AlertDialog.Builder(this).setView(makeDialog)
        val mAlertDialog = mBuilder.show()

        val btnYES = makeDialog.findViewById<Button>(R.id.btnYES)
        val btnNO = makeDialog.findViewById<Button>(R.id.btnNO)
        mAlertDialog.setCancelable(false)

        btnYES.setOnClickListener {
            removeDEPT()
            mAlertDialog.dismiss()
        }

        btnNO.setOnClickListener {
            showMSG("Contact NOT Deleted")
            etPerson.setText("")
            etPhone.setText("")
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            mAlertDialog.dismiss()
        }
        mAlertDialog.show()
    }

    private fun removeDEPT() {

        val db = DBHelper(this)
        val result = db.deleteFRIEND(etPerson.text.toString())

        if (result) {
            showMSG("Contact Removed")
            nextACTIVITY()
        }else{
            // WHY WILL THIS CODE NEVER FIRE ? do you know
            showMSG("NO Match Found")
            nextACTIVITY()
        }
    }

    fun nextACTIVITY(){
        val intent = Intent(this, ViewContactActivity::class.java)
        startActivity(intent)
    }

    fun showMSG(msg:String){
        object : CountDownTimer(4000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tvMsg.visibility = View.VISIBLE
                tvMsg.text = msg
            }
            override fun onFinish() {
                tvMsg.visibility = View.INVISIBLE
                tvMsg.text = ""
            }
        }.start()
    }

     open fun showSNACKBAR(){

         val AC:String
         AC = "CANCEL"
         if(from == "UPDATE"){
             sbSTRING = "To Cancel UPDATE Click ->"
         }else{
             sbSTRING = "To Cancel DELETE Click ->"
         }

        val snackbar = Snackbar.make(findViewById(android.R.id.content),sbSTRING, Snackbar.LENGTH_INDEFINITE)
            .setAction(AC) {
                val intent = Intent(this,MainActivity::class.java)
                intent.putExtra("FROM", "NEW")
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                startActivity(intent) }

        snackbar.setActionTextColor(Color.BLACK)
        val snackbarView = snackbar.view
        snackbarView.setBackgroundColor(Color.LTGRAY)
        val textView = snackbarView.findViewById(android.support.design.R.id.snackbar_text) as TextView
        val actionTextView = snackbarView.findViewById(android.support.design.R.id.snackbar_action)as TextView
        textView.setTextColor(Color.BLUE)
        textView.textSize = 22f
        actionTextView.textSize = 20f
        snackbar.show()
    }

    override fun onBackPressed(){
        if(from == "UPDATE"){
            showSNACKBAR()
        }else if (from == "DELETE"){
            showSNACKBAR()
        }else{
            showMSG("Use View Contact")
        }
    }

}// end Class
